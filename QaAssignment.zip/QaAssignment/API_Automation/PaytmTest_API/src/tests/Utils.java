package tests;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Properties;
import java.util.Set;

import com.google.common.io.Files;

public class Utils {

	public static Object fetchValue(String key) throws IOException 
	{
		FileInputStream file = new FileInputStream("ConfigFile\\apiconfig.properties");
		Properties property = new Properties();
		property.load(file);
		return property.get(key);
		
	}
	
	
	public static String getExtensionByGuava(String filename) 
	{
	    return Files.getFileExtension(filename);
	}
	
	public static boolean areDistinct(String arr[]) 
    { 
        // Put all array elements in a HashSet 
        Set <String> s =  new HashSet<String>(Arrays.asList(arr)); 
  
        // If all elements are distinct, size of 
        // HashSet should be same array. 
        return (s.size() == arr.length); 
    }
	
}
