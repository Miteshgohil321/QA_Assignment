package tests;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.CellReference;
import org.apache.poi.ss.util.CellUtil;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.jayway.restassured.RestAssured;
import com.jayway.restassured.path.json.config.JsonPathConfig;
import com.jayway.restassured.response.Response;

import net.minidev.json.JSONArray;
import net.minidev.json.JSONObject;
import net.minidev.json.parser.JSONParser;

public class getapi extends Utils {

	static String api_URl = "";
	static Response resp;
	SoftAssert softassert = new SoftAssert();
	static String format = ".jpg";
	static int size;

	@Test(priority = 1)
	public void validate_status_code() throws IOException {
		api_URl = Utils.fetchValue("URL_Upcoming_Movies").toString();
		resp = RestAssured.given().get(api_URl);
		size = resp.jsonPath().getList("upcomingMovieData").size();
		softassert.assertEquals(resp.getStatusCode(), 200, "Status code mismatch error");
		softassert.assertAll();
	}

	@Test (priority=2)
	public void validate_movie_poster_format() {
		String act_format = "";

		for (int i = 1; i < size; i++) {
			JsonPathConfig jsonPath = new JsonPathConfig(resp.asString());
			act_format = resp.jsonPath().getString("upcomingMovieData[" + i + "].moviePosterUrl");
			String act_ext = Utils.getExtensionByGuava(act_format);
			softassert.assertEquals(act_ext, "jpg", "Movie Poster URL extension mismatch");
			softassert.assertAll();
		}

	}

	@Test (priority=3)
	public void validate_movie_release_Date() throws ParseException {

		for (int i = 1; i < size; i++) {
			Date date = new Date();
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-dd-MM");
			String todays_date = formatter.format(date);
			JsonPathConfig jsonPath = new JsonPathConfig(resp.asString());
			String resp_date = resp.jsonPath().getString("upcomingMovieData[0].releaseDate");
			softassert.assertNotEquals(todays_date, resp_date, "Date is less than current date ");
			softassert.assertAll();
		}

	}

	@Test (priority=4)
	public void validate_unique_Paytm_Movie_Code() {
		
		Set<String> set2 = new HashSet<>();
		boolean flag = true;
		List<String> duplicate_array = new ArrayList<String>();

		for (int i = 1; i < size; i++) {
			JsonPathConfig jsonPath = new JsonPathConfig(resp.asString());
			String resp_paytm_movie_code = resp.jsonPath().getString("upcomingMovieData[" + i + "].paytmMovieCode");

			List<String> list1 = new ArrayList<String>();
			String s1 = resp_paytm_movie_code;
			if (!set2.add(s1)) {
				flag = false;
				duplicate_array.add(s1);
				softassert.assertTrue(flag, "Paytm Movie Code is not unique");
			}
			list1.add(s1);
		}

//		softassert.assertTrue(flag, "Paytm Movie Code is not unique");
		softassert.assertAll();

	}

	@Test (priority=5)
	public void validate_language() {
		boolean flag = true;
		for (int i = 1; i < size; i++) {
			JsonPathConfig jsonPath = new JsonPathConfig(resp.asString());
			try {

				String resp_language = resp.jsonPath().getString("upcomingMovieData[" + i + "].language");
			} catch (Exception e) {

				flag = false;
			}
		}
		softassert.assertTrue(flag, "More than one Language");
		softassert.assertAll();
	}

	@Test(priority = 6)
	public void write_in_excel() throws IOException {
		int counter = 0;
		Workbook workbook = new XSSFWorkbook();
		Sheet sheet = workbook.createSheet("MoviesContentAs0");
		Row rowhead = null;
		for (int i = 1; i < size; i++) {
			JsonPathConfig jsonPath = new JsonPathConfig(resp.asString());
			String content_available = resp.jsonPath().getString("upcomingMovieData[" + i + "].isContentAvailable");
			if (content_available.equals("0")) {
				JsonPathConfig jsonPath2 = new JsonPathConfig(resp.asString());
				String movie_name = resp.jsonPath().getString("upcomingMovieData[" + i + "].movie_name");
				rowhead = sheet.createRow(counter);
				rowhead.createCell(0).setCellValue(movie_name);
				counter++;
			}
		}

		FileOutputStream outtFile = new FileOutputStream("ConfigFile\\Movie.xlsx");
		workbook.write(outtFile);
		outtFile.close();
	}

}
