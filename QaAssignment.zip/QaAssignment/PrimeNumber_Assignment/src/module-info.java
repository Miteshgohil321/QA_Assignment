/**
 * 
 */
/**
 * @author mites
 *
 */
module PrimeNumber_Assignment {
}